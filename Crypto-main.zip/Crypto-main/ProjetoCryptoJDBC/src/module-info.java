module ProjetoCrypto {
	requires java.sql;
}